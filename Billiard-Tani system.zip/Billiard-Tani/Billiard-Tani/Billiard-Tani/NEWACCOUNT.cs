﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Billiard_Tani
{
    public partial class NEWACCOUNT : Form
    {
        public NEWACCOUNT()
        {
            InitializeComponent();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string username = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();
            string fullname = textBox3.Text.Trim();
            string contactno = textBox4.Text.Trim();
            string address = textBox5.Text.Trim();

            // Check if username or password is empty
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and password cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method early if validation fails
            }

            try
            {
                Connection.Connection.DB();

                string insertQuery = "INSERT INTO users (username, [password], fullname, contactno, address) VALUES (?, ?, ?, ?, ?)";
                OleDbCommand insertCmd = new OleDbCommand(insertQuery, Connection.Connection.conn);
                insertCmd.Parameters.AddWithValue("@username", username);
                insertCmd.Parameters.AddWithValue("@password", password);
                insertCmd.Parameters.AddWithValue("@fullname", fullname);
                insertCmd.Parameters.AddWithValue("@contactno", contactno);
                insertCmd.Parameters.AddWithValue("@address", address);

                int rowsAffected = insertCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Successfully Created!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Direct to Form1

                    this.Hide();
                    Form1 form = new Form1();
                    form.Show();
                }
                else
                {
                    MessageBox.Show("Error.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        private void label8_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}
